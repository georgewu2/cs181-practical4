CS181 Practical 4
=================
### Reinforcement Learning
George Wu, Lisa Wang, Allen Chen

## Running the code
First unzip the zip archive and navigate into the `practical4-code` directory. Basic usage is as follows:

	python stub.py

## Dependencies
* numpy
* pygame
